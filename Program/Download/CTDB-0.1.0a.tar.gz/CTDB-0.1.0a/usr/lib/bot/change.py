import datetime
import bot.webhooks as webhooks

def main(con , tit , des , datatable):
    fields = []
    
    for i in datatable:
        fs = i.split(' | ')
        if len(fs) == 2:
            fs = {
                "name": fs[0],
                "value": fs[1],
                "inline": False
            }
            fields.append(fs)
    
    table = {
        "username" : "ระบบอัพเดท",
        "content": con, 
        "allowed_mentions" : {
            "roles" : ["1439152119427895396"]
        },
        "embeds" : [
            {
                "title": tit,
                "description" : des,
                "color" : 65280,
                "fields" : fields,
                "footer" : {"text": f"ข้อมูลอัปเดต {datetime.datetime.now()}"}
            }
        ]
        
    }
    print(table)
    
    webhooks.main(table)