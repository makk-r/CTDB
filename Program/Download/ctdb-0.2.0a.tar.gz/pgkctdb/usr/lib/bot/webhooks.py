import requests
import json
import datetime

def main(data, url):
    # URL Webhook
    WEBHOOK_URL = url

    # ส่งคำขอ POST
    try:
        response = requests.post(
            WEBHOOK_URL,
            data=json.dumps(data),
            headers={'Content-Type': 'application/json'}
        )
        
        if response.status_code == 204:
            print("✅ ส่งข้อความแชทปกติสำเร็จ!")
        else:
            print(f"❌ ส่งข้อความล้มเหลว! รหัสสถานะ: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"เกิดข้อผิดพลาดในการเชื่อมต่อ: {e}")