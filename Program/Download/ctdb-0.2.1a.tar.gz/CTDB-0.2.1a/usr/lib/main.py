import tkinter as tk
from tkinter import ttk
import socket
import os
import sys
from dotenv import load_dotenv
import tkinter as tk
import json
import bot.change as ce
import loginfile

root = tk.Tk()

name_variable = tk.StringVar()
passwordbox_variable = tk.StringVar()

namehome = socket.gethostname()

"""------------------------------------------------อย่าลืมแก้ตรงนี้ด้วย------------------------------------------------"""

current_dir = '/usr/share/ctdb'

"""------------------------------------------------อย่าลืมแก้ตรงนี้ด้วย------------------------------------------------"""

code = f'{current_dir}/code'

load_dotenv(dotenv_path=f'{code}/.env')

send = None

User = None

boollogin = False

def login(event):
    global boollogin
    global send
    global User
    data = {
        'name' : name_variable.get(),
        'password' : passwordbox_variable.get()
    }
    logindef, responsecode = loginfile.main(name_variable.get(), passwordbox.get())
    if responsecode != 200:
        print(logindef)
    else:
        User = logindef
        send = True
    if send:
        boollogin = True
        root.destroy()

root.title("ควบคุม bot-descord")

label1 = ttk.Label(root, text="Login")

label1.pack(padx=20, pady=20)

def next_box(event):
    passwordbox.focus_set()

namebox = ttk.Entry(root, textvariable=name_variable, width=40)
namebox.pack(padx=10, pady=5)
namebox.bind('<Return>', next_box)

namebox.focus()

passwordbox = ttk.Entry(root, textvariable=passwordbox_variable, width=40, show='#')
passwordbox.pack(padx=10, pady=5)
passwordbox.bind('<Return>', login)

root.mainloop()

if boollogin == False:
    sys.exit()

name = name_variable.get()
loginwin = tk.Tk()
loginwin.title(name)

titbox = tk.StringVar()
desbox = tk.StringVar()
conbox = tk.StringVar()

label1 = ttk.Label(loginwin ,text = 'ข้อความที่เราต้องการจะส่ง')
label1.pack(padx=20, pady=5)

label5 = ttk.Label(loginwin ,text = 'หัวข้อใหญ่รวมๆ')
label5.pack(padx=20, pady=5)
con = ttk.Entry(loginwin, textvariable = conbox, width=40)
con.pack(padx=10, pady=5)
con = con.focus()

label2 = ttk.Label(loginwin ,text = 'หัวข้อหลัก')
label2.pack(padx=20, pady=5)
tit = ttk.Entry(loginwin, textvariable = titbox, width=40)
tit.pack(padx=10, pady=5)

label3 = ttk.Label(loginwin ,text = 'รายละเอียด')
label3.pack(padx=20, pady=5)
des = ttk.Entry(loginwin, textvariable = desbox, width=40)
des.pack(padx=10, pady=5)

table = []

def fie():
    
    global table
    
    fiebox = tk.StringVar()
    table.append(fiebox)
    fie = ttk.Entry(loginwin, textvariable=fiebox, width=40)
    fie.pack(padx=20, pady=5)
    
def sendbot():
    globals , conbox , titbox , desbox , table
    datatable = []
    for i in table:
        datatable.append(i.get())
    ce.main(conbox.get() , titbox.get() , desbox.get() , datatable, User['user']['url'])

label4 = ttk.Label(loginwin ,text = 'หัวข้อย่อย')
label4.pack(padx=20, pady=5)
addfie = ttk.Button(loginwin, text = 'ส่ง', command=sendbot)
addfie.pack(padx=20, pady=5)

addfie = ttk.Button(loginwin, text = 'เพิ่มรายละเอียด', command=fie)
addfie.pack(padx=20, pady=5)

loginwin.mainloop()