import requests
from dotenv import load_dotenv
import os

"""------------------------------------------------อย่าลืมแก้ตรงนี้ด้วย------------------------------------------------"""

current_dir = '/usr/share/ctdb'

"""------------------------------------------------อย่าลืมแก้ตรงนี้ด้วย------------------------------------------------"""


code = f'{current_dir}/code'

load_dotenv(dotenv_path=f'{code}/.env')

url = os.getenv('url')

Login_URL = os.getenv('login')

XAK = os.getenv('XAK')

XAK = {"X-API-Key" : XAK}

print(requests.get(url).json()["status"])

def main(name, password):
    payload = {
        "name" : name,
        "password" : password
    }

    try:
        response = requests.get(Login_URL,headers=XAK,json=payload)
        responsecode = response.status_code
        if responsecode == 200:
            response = (response.json())
        else:
            response = response.json()['message']
        
    except requests.exceptions.RequestException as e:
        print(f"Connection Error: {e}")
        return None
    return response, responsecode